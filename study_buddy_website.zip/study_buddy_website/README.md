# Study Buddy — Website Edition (No AI Chatbot)

Study Buddy is a standalone HTML, CSS, and JavaScript study dashboard. This ZIP contains the website source files only; it is **not an APK**.

## Features
- Student dashboard with Maths, Physics, Chemistry, and Computer Science
- Notes saved in the browser's local storage
- Study task tracker and progress indicator
- Focus timer
- Quiz bank with 40 questions across Mathematics, Physics, Chemistry, Computer Science, and General Knowledge
- Randomized quiz rounds with category selection and explanations
- No AI chatbot, API key, backend server, or paid API required

## Run the website on Android
1. Extract this ZIP using your phone's Files app.
2. Upload `index.html` to a static website host, such as GitHub Pages or Netlify, or open it in a local HTML preview app.
3. Visit the website URL in Chrome.

## Publish it online
### Netlify (simple option)
1. Open Netlify in your browser and sign in.
2. Choose the option to add/deploy a site by manual deploy.
3. Upload the extracted project folder containing `index.html`.
4. Open the generated website URL.

### GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` to the repository's top level.
3. In the repository settings, open **Pages** and enable deployment from the main branch/root folder.
4. Open the website URL GitHub Pages provides.

## Important notes
- Notes and tasks are stored in that browser's local storage on that device. They are not automatically synced between devices.
- Clearing browser/site data may erase saved notes and tasks.
- The quiz uses a built-in question bank; it does not generate new questions automatically.
- This package is a website project in ZIP format, not an APK.
